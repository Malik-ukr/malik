<template>
<div>
   <v-card>
      <v-tabs
        background-color="deep-purple"
        center-active
        dark
      >
        <v-tab>Random Chart</v-tab>
         <v-tab-item>
          <random-chart/>
        </v-tab-item>

        <v-tab>Uma Formula</v-tab>
        <v-tab-item>
          <UMAFormula></UMAFormula>
        </v-tab-item>
        
        
        <v-tab>Formula 2</v-tab>
        <v-tab>Formula 3</v-tab>

        
        
      </v-tabs>
    </v-card>

</div>
</template>

<script>

  import RandomChart from '../components/RandomChart'
  import UMAFormula from '../components/Uma_formula'


  export default {
    name: 'Formulas',
    

    components: {
      
        UMAFormula,  
        RandomChart,
        
    },
  }
</script>
